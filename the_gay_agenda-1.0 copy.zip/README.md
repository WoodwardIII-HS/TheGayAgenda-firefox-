# The Gay Agenda

This is a just-for-fun Firefox add on that rethemes google calendar with several LGBTQ+ color schemes. Copied from Abhay Deshpande
